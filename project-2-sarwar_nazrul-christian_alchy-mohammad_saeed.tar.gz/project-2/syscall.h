#include <unistd.h>
#include <sys/syscall.h>
extern int errno;
long int Lsyscall(...);
